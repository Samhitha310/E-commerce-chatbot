import json
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.svm import SVC
from sklearn.pipeline import make_pipeline
from flask import Flask, render_template, jsonify, request, redirect, url_for, session
from werkzeug.security import generate_password_hash, check_password_hash
from flask_pymongo import PyMongo
import os
from flask_limiter import Limiter


app = Flask(__name__, static_folder='static', template_folder='templates')
app.secret_key = os.urandom(24)

limiter = Limiter(app)
limiter.init_app(app)

# MongoDB configuration
app.config["MONGO_URI"] = "mongodb://localhost:27017/registered_data"
mongo = PyMongo(app)

# Chatbot class using ML model
class MLChatBot:
    def __init__(self, dataset_path):
        # Load and preprocess the dataset
        with open(dataset_path, 'r') as file:
            data = json.load(file)

        questions = [item['question'] for item in data['questions']]
        answers = [item['answer'] for item in data['questions']]

        # Create a pipeline with TF-IDF vectorizer and SVM classifier
        self.model = make_pipeline(TfidfVectorizer(), SVC(kernel='linear'))
        self.model.fit(questions, answers)

    def generate_response(self, user_input):
        # Use the trained model to predict the response
        response = self.model.predict([user_input])
        return response[0]

# Create an instance of the chatbot
ml_chatbot = MLChatBot("Ecommerce_FAQ_Chatbot_dataset.json")  # Replace with the actual path to your dataset

# Flask routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/products')
def products():
    return render_template('products.html')

@app.route('/account', methods=['GET', 'POST'])
def account():
    if request.method == 'POST':
        data = request.get_json()
        username = data.get('username')
        email = data.get('email')
        password = data.get('password')
        
        # Hash the password for security
        hashed_password = generate_password_hash(password)
        
        # Check if the user already exists
        if mongo.db.accounts.find_one({'username': username}):
            return jsonify({'success': False, 'message': 'Username already exists!'}), 400
        
        # Insert the user into MongoDB
        mongo.db.accounts.insert_one({
            'username': username,
            'email': email,
            'password': hashed_password
        })
        
        return jsonify({'success': True, 'message': 'Registration successful!'})
    
    return render_template('account.html')  # For GET requests

@app.route('/login', methods=['POST'])
@limiter.limit("5 per minute")  # Rate limit to prevent brute-force attacks
def login():
    try:
        data = request.get_json()  # Get JSON data from the request
        print(f"Login data received: {data}")  # Debugging output

        # Validate that the username and password fields are provided
        if 'username' not in data or 'password' not in data:
            return jsonify({'success': False, 'message': 'Username and password are required!'}), 400

        username = data['username']  # Extract username
        password = data['password']  # Extract password
        
        # Find the user in MongoDB based on the username
        user = mongo.db.accounts.find_one({'username': username})
        print(f"User found: {user}")  # Log the found user (or None)

        # Check if the user exists and validate the password
        if user and check_password_hash(user['password'], password):
            session['user_id'] = str(user['_id'])  # Store user ID in session for tracking
            return jsonify({'success': True, 'message': 'Login successful!'}), 200  # Successful login response
        else:
            return jsonify({'success': False, 'message': 'Invalid credentials!'}), 401  # Unauthorized response
    except Exception as e:
        print(f"An error occurred: {e}")  # Log any unexpected errors
        return jsonify({'success': False, 'message': 'An internal error occurred. Please try again later.'}), 500  # Internal server error response


@app.route('/cart')
def cart():
    return render_template('cart.html')

@app.route('/send_message', methods=['POST'])
def send_message():
    user_input = request.json['user_input']
    response = ml_chatbot.generate_response(user_input)
    return jsonify({"response": response})

if __name__ == "__main__":
    app.run(debug=True)

